import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  pageTitle: string = "Create a new account today"
  pageDescription: string ="It's free and always will be!"
  successMessage:string
  errorMessage:string

  constructor(private router:Router,private userService : UserService) { }

  ngOnInit() {
  }

  onSubmit(user:User){
    this.userService.registerUser(user).subscribe(
      message=>{
        this.successMessage=message
      },
      message=>{
        this.errorMessage=message
      }
    )
    this.router.navigate(['/login'])
  }
}