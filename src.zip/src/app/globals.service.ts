import { Injectable } from '@angular/core';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class GlobalsService {

  constructor() { }

  currentUser:User;
 public dummy:string="SAMPLE";
}