import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';
import { GlobalsService } from '../globals.service';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle1:string="Already a user?"
  pageTitle2:string="Sign in here"
  errorMessage:string
  user:User
  _emailId:string
  _password:string
  constructor(private router:Router,private userService : UserService,private global:GlobalsService) { }

  ngOnInit() {
    
  }
  get emailId():string{
    return this._emailId
  }

  set emailId(value:string){
    this._emailId=value
  }

  get password():string{
    return this._password
  }

  set password(value:string){
    this._password=value
  }

  onClick(){
    this.userService.loginUser(this._emailId,this._password).subscribe(
      user=>{
        console.log(this._emailId)
        console.log(user)
        localStorage.setItem('user',JSON.stringify(user))
        console.log(JSON.parse(localStorage.getItem("user")))
        console.log('This segment works')

      },
      error=>{
        console.log('Error Segment')
      }
    )
    this.router.navigate(['/wall'])
  }
}