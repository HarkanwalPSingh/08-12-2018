import { Address } from "./address";

export interface User {
	userId:number,
    firstName:string,
	lastName:string,
	dob:string,
	emailId:string,
	gender:string,
	password:string,
	address:Address
}