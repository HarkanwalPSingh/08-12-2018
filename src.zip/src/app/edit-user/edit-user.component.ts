import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';
import { EditUser } from '../edit-user';
@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  user:User
  editUser: EditUser
  errorMessage:string
  successMessage:string
  constructor(private router:Router,private userServices : UserService,private route:ActivatedRoute) { }

  ngOnInit() {
    const emailId = this.route.snapshot.paramMap.get("emailId")
    this.userServices.getUser(emailId).subscribe(
      user=>{
        this.user=user
      },
      errorMessage=>{
        this.errorMessage=errorMessage
      }
    )
  }

  onSubmit(editUser:EditUser){
    this.editUser=editUser
    this.userServices.editUser(editUser).subscribe(
      message=>{
        this.successMessage=message
      },
      message=>{
        this.errorMessage=message
      }
    )
    this.router.navigate(['/wall',this.user.emailId])
  }
  

}
